# Retro Bowl College — Editable Source Conversion

This is a **source conversion of the actual original Retro Bowl College HTML5 game**, not a remake or clone.

The original GameMaker build (`__pristine_backup/retro-bowl-college-main/html5game/RetroBowl.js`) is preserved verbatim. This project reorganizes that same code into individually editable source files and rebuilds it into a playable HTML5 game that behaves identically to the original.

## What this is
- The **actual original game code and assets**, split into navigable files.
- Every `gml_*` function name, object, room, sprite, sound, and resource ID kept byte-identical.
- The original GameMaker runtime kept intact (no rewriting, no monkey-patching, no mod loader).

## What this is NOT
- Not a new game, not a recreation, not a clone.
- Not a replacement of working systems with simplified versions.
- Not dependent on runtime hooks for ordinary modifications.

## Project layout
```
src/
├── engine/            # GameMaker runtime (verbatim; do not edit)
├── game_data/         # JSON_game split by section (sounds, sprites, objects, rooms, fonts...)
├── scripts/           # gml_Script_* functions (2,059) + gml_GlobalScript_* namespaces (~150)
├── objects/           # gml_Object_*_* event handlers (536)
├── menus/             # per-screen menu source + planned menu framework
├── assets/            # textures, audio, data files (copied from original)
├── tools/             # build, index, asset-catalog scripts
├── index/             # generated searchable code index (JSON + markdown)
└── build/             # build output (gitignored)
```

## Build
```
npm install
npm run build
```
Produces `build/html5game/RetroBowl.js`, which is concatenated in the original GameMaker execution order and is playable as-is (serve `build/` over HTTP and open `build/index.html`).

## Test
```
npm test
```
Runs the regression suite: build verification, asset availability, and source-edit verification. See `docs/REGRESSION_TESTING.md` for details.

## Important notes
- **Music is silent.** Two music sounds (`snd_music`, `snd_music_co`) are declared in the original data but no `.ogg` files were included in the provided build. All 25 sound effects work. This is a pre-existing condition of the source build, not introduced by this conversion.
- **Do not rename `gml_*` functions or `JSON_game` keys.** The runtime and game code reference them by name.
- Files in `src/engine/runtime.js` are the GameMaker runtime. Do not rewrite them.

## Pristine backup
The untouched original build is at `__pristine_backup/retro-bowl-college-main/`. Never modify it.
