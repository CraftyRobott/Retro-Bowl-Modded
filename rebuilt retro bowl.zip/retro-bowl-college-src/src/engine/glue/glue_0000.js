 // /// @description  (then:script[ok; custom], custom)
// /// @param then:script[ok; custom]
// /// @param  custom
