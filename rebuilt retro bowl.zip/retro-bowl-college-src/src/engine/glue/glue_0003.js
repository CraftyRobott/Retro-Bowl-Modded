 // /// @description  (script, result, custom)~
// /// @param script
// /// @param  result
// /// @param  custom
