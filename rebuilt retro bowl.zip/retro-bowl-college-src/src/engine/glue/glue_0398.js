 // ///	@return {bool} New team added
