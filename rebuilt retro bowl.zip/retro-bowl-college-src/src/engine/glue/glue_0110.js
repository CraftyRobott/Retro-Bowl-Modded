 // 					ds_list_add(other.l_team, s_get_human_opponent_sla_prefix("@", wk) + opp_map[? "tla"]);
// 				if (string_count("@", l_team[| i])) draw_set_alpha(0.7);
