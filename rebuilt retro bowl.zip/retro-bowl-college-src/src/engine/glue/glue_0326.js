 // 			slog("DELETING PLAYER @["+string(del_index)+"]: " + string(pmap[? "lname"]));
