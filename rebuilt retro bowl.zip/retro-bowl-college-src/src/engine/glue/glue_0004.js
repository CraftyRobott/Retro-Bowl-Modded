
var gmcallback_poki_closure = gml_Script_gmcallback_poki_closure;
