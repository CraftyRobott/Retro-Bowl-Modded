# Menu Framework — Retro Bowl College

This document describes how the **original** Retro Bowl College implements menus/screens, and the **additive menu framework** layer provided on top of it so developers can edit existing screens and create new ones integrated with real game state.

---

## 1. How the original game implements menus

Every screen in the original game is a **GameMaker room** (`rm_title`, `rm_roster`, `rm_choose_team`, `rm_options`, …). A room's contents are instances placed at design time. Each instance is configured by a **PreCreate** script (`gml_RoomCC_<room>_<n>_PreCreate.js`) that sets properties on the instance, and the instance's object provides the behavior via **Create / Step / DrawGUI** events.

### 1.1 The button object (`obj_button` and family)

Most interactive menu elements are instances of `obj_button` (or its siblings `obj_button_color`, `obj_button_sqr`, `obj_button_thin`, `obj_button_small`, `obj_button_med`, `obj_button_med_slim`, `obj_button_big`, `obj_button_team`).

Relevant instance properties (set in PreCreate, read at runtime):

| Property | Meaning |
|----------|---------|
| `gmltext` | Button label (shown via `gml_Script_draw_hd_text`) |
| `gmlimage` / `gmlbtn_image` | Sprite shown on the button |
| `gmlonClickAction` | Script executed when clicked (`script_execute(_inst, _other, gmlonClickAction)`) |
| `gmlgoto_room` | Room to switch to on click (alternative to `gmlonClickAction`) |
| `gmlactive` | `false` disables the button entirely |
| `gmlhover` / `gmlclicked` | Visual state (managed by the Step event) |
| `gmlcolour` / `gmlcolour_text` | Button face / text colour |
| `gmlgp_mapped_button` / `gmlgp_mapped_hidden` | Gamepad button that activates it |
| `gmlcustom_draw_gui` | If not `-4`, a custom draw method is called instead of the default |

**Event responsibilities:**
- `Create` (`gml_Object_obj_button_Create_0`): sets default colour based on QB mode / background.
- `Step` (`gml_Object_obj_button_Step_0`): handles hover, mouse click, and gamepad activation. On release it either `room_goto(gmlgoto_room)` or `script_execute(..., gmlonClickAction)`. Plays `snd_click` if sound FX enabled.
- `DrawGUI` (`gml_Object_obj_button_Draw_64`): draws the sprite + centered text (uppercased), with hover/click/selected visual feedback.

### 1.2 The text object (`obj_text`)

Purely decorative text. Properties: `gmltext`, `gmlfont`, `gmlhalign`, `gmlvalign`, `gmlcolour` (box), `gmltcolour` (text), `gmlalpha`, `gmlshadow`, `gmlicon` (+frame/left), `gmldraw_box`, `gmlflashtext`. Drawn in DrawGUI via `gml_Script_draw_hd_text_color`.

### 1.3 Room layout / instance placement

Each room's instances are configured in one or more `gml_RoomCC_<room>_<n>_PreCreate.js` files. Example from `rm_roster`:

```js
_inst.gmltext = gml_Script_s_str(_inst, _inst, "ui_Roster");           // label
_inst.gmlonClickAction = kgml_Script_btn_click_Roster_Back;            // action
_inst.gmlimage = YYASSET_REF(0x0100008e);                              // sprite
_inst.gmlgp_mapped_hidden = global.gmlgp_back;                         // gamepad back
_inst.gmlgoto_room = YYASSET_REF(0x03000022);                          // room to open
_inst.gmlinfo_msg = "info_StarPlayers";                                // info tooltip key
```

### 1.4 Navigation

- `room_goto(<room_asset_ref>)` — switch rooms.
- `script_execute(_inst, _other, <button>.gmlonClickAction)` — run a button's action script (which itself usually calls `room_goto`).
- Rooms are referenced by numeric GameMaker asset refs (`YYASSET_REF(0x030000XX)`); the `code_index.json` / `CODE_INDEX.md` map room names → refs.

### 1.5 Input

- Mouse/touch: `point_in_rectangle(device_mouse_x_to_gui(0), …)` + `mouse_check_button(1)` / released.
- Gamepad: `gamepad_button_check(slot, gmlgp_mapped_button)` + select button.
- Escape / back: handled per-object (`KeyPressed_ESCAPE`) on dialogs like `obj_news_dyn`.

### 1.6 The global state object

`YYASSET_REF(0x00000062)` is the persistent game-state object (`obj_nx`-like). It holds `gmlroster`, `gmldraftlist`, `gmlfreeagentlist`, `gmltradelist`, `gmlmyteam_id`, `gmlmap_options` (sound FX toggle), `gmlqb_mode`, etc. Menus read/write this directly.

---

## 2. Additive menu framework

The framework lives in `src/menus/framework/` and is **additive**: it defines new functions with a `menu_framework_` prefix and never overrides any original `gml_*` function or `JSON_game` key. It is concatenated after all original code in `build_order.json`, so the original game is untouched and the framework can be ignored by developers who only want to edit original screens.

Framework files are plain JS using the original GameMaker runtime APIs (`instance_create_layer`, `draw_sprite_ext`, `room_goto`, `script_execute`, `audio_play_sound`, `YYASSET_REF`, `ds_*`, etc.), so framework-built screens integrate with real game state, assets, saves, and input — they are **not** HTML mockups.

### 2.1 Provided primitives

All functions take `(_inst, _other)` as the first two arguments (GameMaker event signature convention) and return the created instance id.

| Function | Purpose |
|----------|---------|
| `menu_framework_create_button(_inst, _other, x, y, text, sprite, onClickAction, gotoRoom, opts)` | Create a button. `opts` may include `active`, `colour`, `textColour`, `gpButton`, `gpHidden`, `imageNum`, `continueIcon`, `flash`, `customDraw`. |
| `menu_framework_create_text(_inst, _other, x, y, text, opts)` | Create a text label. `opts`: `font`, `halign`, `valign`, `colour`, `textColour`, `alpha`, `shadow`, `icon`, `iconLeft`, `iconFrame`, `drawBox`, `flashText`. |
| `menu_framework_create_box(_inst, _other, x, y, sprite, opts)` | Create a panel/box (obj_smallbox / obj_infobox style). `opts`: `colour`, `alpha`, `drawBox`. |
| `menu_framework_create_list(_inst, _other, x, y, w, h, itemHeight, items, onItemClick, opts)` | Scrollable list of items. Renders each item as a row with text + optional sprite; handles up/down scrolling via mouse wheel / gamepad. |
| `menu_framework_create_tabs(_inst, _other, x, y, tabLabels, onTabChange, opts)` | Tab strip; activates one tab panel at a time. |
| `menu_framework_navigate(room)` | Wrapper around `room_goto` that also plays the click sound if SFX enabled. |
| `menu_framework_assign_action(buttonInstance, actionScript)` | Set/replace `gmlonClickAction` on an existing button instance. |
| `menu_framework_play_click()` | Play `snd_click` if options say so. |
| `menu_framework_is_sfx_on()` | Read `gmlmap_options.op_soundfx` from global state. |

### 2.2 Creating a new screen (example)

A new screen is a new room + PreCreate files that use the framework primitives:

```js
// src/menus/custom/rm_my_screen_0_PreCreate.js  (additive; added to build_order.json)
function gml_RoomCC_rm_my_screen_0_PreCreate(_inst, _other) {
  // "Back" button that returns to home (rm_home = 0x0300000e per index)
  menu_framework_create_button(_inst, _other, 100, 400, "Back", -1,
    null, YYASSET_REF(0x0300000e), { gpButton: global.gmlgp_back });

  // A button that runs a custom action script
  menu_framework_create_button(_inst, _other, 300, 400, "Custom", -1,
    gml_Script_my_custom_action, null, { textColour: 16777215 });

  // Title text
  menu_framework_create_text(_inst, _other, 400, 80, "My Screen", {
    font: global.gmlfnt_small_flex,
    halign: 1, valign: 1, textColour: 16777215,
  });
}
```

The action script receives `(_inst, _other)` and can read/write real game state:

```js
// src/scripts/custom/gml_Script_my_custom_action.js
function gml_Script_my_custom_action(_inst, _other) {
  var state = YYASSET_REF(0x00000062);   // global game state
  // … read state.gmlroster, modify, save, then navigate …
  menu_framework_navigate(YYASSET_REF(0x03000019));
}
```

### 2.3 Replacing an existing screen

Because rooms are looked up by asset ref and the framework uses the same `room_goto` / `script_execute` mechanics, you can replace a screen by:
1. Creating a new room (e.g. `rm_roster_custom`) with your own PreCreate files.
2. Changing any button that previously `room_goto`ed to `rm_roster` to instead `room_goto` to `rm_roster_custom`.
3. The original `rm_roster` room and its code remain intact and unused.

### 2.4 Modifying an existing screen

Edit the room's PreCreate files under `src/rooms/` (e.g. `gml_RoomCC_rm_roster_0_PreCreate.js`) to change labels, sprites, actions, or positions. Or use `menu_framework_assign_action` in a small additive script that runs after room creation.

---

## 3. Original screen map

| Screen | Room | Primary objects | Notes |
|--------|------|-----------------|-------|
| Title / main menu | `rm_title` | obj_button, obj_text, obj_roomtitle | Entry point |
| Home / HC hub | `rm_home` | obj_button, meters, obj_box_* | Main hub after title |
| Team selection | `rm_choose_team`, `rm_choose_team_college` | obj_button_team, obj_button, obj_text | Pick a team |
| Face/avatar | `rm_choose_face` | obj_kb_key, obj_button | Create-face |
| Roster | `rm_roster` | obj_roster, obj_button, obj_text, obj_player_image | Team roster grid |
| Player profile | `rm_profile_player` | obj_player_profile, obj_player_image, obj_box_* | Player detail |
| Staff profile | `rm_profile_staff` | obj_staffprofile | Staff detail |
| Boss profile | `rm_profile_boss` | obj_bossprofile | Coach detail |
| Draft | `rm_draft`, `rm_draft_college` | obj_college_nfl_draft, obj_button | Draft |
| Free agents | `rm_freeagents`, `rm_freeagents2` | obj_button, obj_text | Free agents |
| Front office | `rm_frontoffice` | obj_button, obj_box_* | Front office |
| League | `rm_league`, `rm_league_college` | obj_button, obj_text, league scripts | Standings/league |
| Stats | `rm_stats`, `rm_stats_player` | obj_stats_player_rm, obj_button | Statistics |
| Options / settings | `rm_options`, `rm_options2`, `rm_options_controls`, `rm_options_mapping`, `rm_options_exh` | obj_checkbox, obj_input_box, obj_kb_key | Settings/controls |
| Match UI | `rm_match`, `rm_pre_match`, `rm_post_match` | obj_btn_*, meters | In-game UI |
| Playoffs | `rm_playoffs`, `rm_playoffs2` | obj_button, obj_text | Playoffs |
| Hall of Fame | `rm_halloffame*` | obj_halloffame_*, obj_text | HOF |
| QB career | `rm_qb_*` | obj_rm_qb_*, obj_negotiate_num | QB life cycle |
| Exhibition | `rm_exhibition`, `rm_exhibition_postmatch`, `rm_exhibition_options` | obj_exhibition_* | Exhibition |
| Team editor | `rm_team_editor` | obj_button, obj_text | Edit team |
| Meeting player | `rm_meeting_player` | obj_box_*, obj_button | Player meeting |
| Details | `rm_details` | obj_button, obj_text | Details |
| Training | `rm_training` | obj_button, meters | Training |
| Season tally | `rm_season_tally` | obj_button, obj_text | End of season |
| Postseason | `rm_postseason` | — | Postseason |

See `src/index/CODE_INDEX.md` → "Search by Room / Screen" for the full per-room object lists.

---

## 4. Asset references used by menus

Menus reference sprites, sounds, and rooms by GameMaker numeric asset refs:

- Rooms: `YYASSET_REF(0x030000XX)` — see `src/index/code_index.json` → `rooms[]` for name↔ref mapping.
- Sprites: `YYASSET_REF(0x010000XX)` — see `asset_catalog.json`.
- Sounds: `YYASSET_REF(0x020000XX)` — `snd_click` is `0x02000006` (used by buttons).
- Fonts: `global.gmlfnt_small_flex`, `global.gmlfnt_*`.

The `code_index.json` `unresolvedGmlReferences` list records GameMaker built-ins/runtime calls the framework may also use.

---

## 5. Constraints & limitations

- **Do not rename** any `gml_*` function, `JSON_game` key, or asset ref — the runtime and game code reference them by name/number.
- **Do not convert to ES modules** — everything stays in the global scope exactly as GameMaker emitted it.
- Framework functions are **additive only**; they must not override original `gml_*` names.
- Music is silent in the source build (`snd_music` / `snd_music_co` `.ogg` files missing); SFX work.
- The framework runs on the original GameMaker renderer (canvas, pixelated), not HTML/DOM.
