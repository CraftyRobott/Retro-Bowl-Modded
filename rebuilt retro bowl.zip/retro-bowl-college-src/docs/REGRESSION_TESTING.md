# Regression Testing — Retro Bowl College

This document describes the regression testing system for the Retro Bowl College editable source conversion.

## Test Suite Location

All tests live in `tests/`:

| File | Purpose |
|------|---------|
| `tests/run_regression.js` | Master test runner — runs all suites |
| `tests/verify_build.js` | Build succeeds, original preserved, functions present |
| `tests/verify_assets.js` | All assets available in build |
| `tests/verify_source_edit.js` | Source edit → rebuild → revert → rebuild |

## How to Run Tests

```bash
# Run the full regression suite
npm test

# Run individual suites
npm run test:build      # build verification only
npm run test:assets     # asset availability only
npm run test:source-edit # source-edit verification only
```

## What Is Tested Automatically

### 1. Build Verification (`verify_build.js`)
- **Build completes without error**: `node tools/build.js` exits with code 0
- **Build output exists**: `build/html5game/RetroBowl.js` is produced
- **Original preserved byte-for-byte**: The pristine original (`__pristine_backup/.../RetroBowl.js`) is preserved exactly as a prefix of the built file
- **All 4,100 original functions present**: Every `gml_*` function declaration found in the original is also found in the build

### 2. Asset Availability (`verify_assets.js`)
Checks that every original asset is present in `build/html5game/` so hardcoded `html5game/...` paths resolve:
- `RetroBowl.js`, `index.html`, `poki-sdk.js`, `uph_poki.js`, `splash.png`
- 4 texture pages (`RetroBowl_texture_0..3.png`)
- Audio worklet (`sound/worklets/audio-worklet.js`)
- 25 sound effects (`snd_*.ogg`)
- 20 data files (`.txt`, `Editor.json`)
- 6 v2 data files (`v2/Teams_CO.txt`, `v2/Schedule_CO.txt`, etc.)

### 3. Source-Edit Verification (`verify_source_edit.js`)
Makes a controlled, reversible modification to a non-critical function:
- Modifies `gml_Script_s_title_create` (adds a test marker comment)
- Rebuilds and verifies the marker appears in the built output
- Restores the original function
- Rebuilds and verifies the marker is gone and the original is restored
- Verifies the final build preserves the pristine original byte-for-byte

**This proves that source-level edits are reflected in the built game.**

## What Requires Manual Testing (Browser-Based)

Browser automation (Playwright) is not available in this environment, and the in-app browser tool is restricted. The following must be verified manually by opening `build/index.html` in a browser:

| Test | Steps | Expected Result |
|------|-------|-----------------|
| Game initialization | Open `build/index.html` | Game loads to title screen, no console errors |
| Main menu | Click CONTINUE | Advances past welcome screen |
| Menu navigation | Navigate through title → home → roster → options | Each screen loads correctly |
| Team selection | Go to team selection screen | Teams display correctly |
| Roster loading | Open roster screen | Player cards render |
| Starting a game | Start a match from home screen | Match UI loads |
| Gameplay interactions | Play a few plays | Ball moves, scores update |
| End-of-game transitions | Finish a match | Post-match screen loads |
| Save/load behavior | Save game, restart, load | Save persists |
| Sound initialization | Click buttons | `snd_click` plays (if audio enabled) |

### Manual Test Procedure

1. Serve the build over HTTP:
   ```bash
   cd build
   python3 -m http.server 4000
   ```
2. Open `http://localhost:4000/` in a browser
3. Work through the manual test table above
4. Check the browser console for errors (open DevTools → Console)
5. Check the Network tab for 404s on assets

## Known Limitations

- **Music is silent**: Two music sounds (`snd_music`, `snd_music_co`) are declared in `JSON_game` but no `.ogg` files were included in the source build. All 25 sound effects work. This is pre-existing to the source build.
- **No browser automation**: Playwright is not installed and browser tools are restricted. Browser-based tests are manual.
- **Poki SDK**: The real Poki SDK is not required; a minimal shim is provided (`build/poki-sdk.js`). Ad/platform features are no-ops locally.

## How to Diagnose Failures

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| Build exits non-zero | Source file missing or syntax error | Read build output; check `tools/build.js` error |
| `prefixOk: false` in build | Original file was modified | Restore from `__pristine_backup/` |
| Missing function in build | `build_order.json` is out of date | Re-run `node tools/extract_source.js` |
| Missing asset in build | Asset not copied by build.js | Check `tools/build.js` `copyDir` calls |
| 404 on asset in browser | Build directory not served correctly | Serve `build/` as web root, not a subdirectory |

## How to Verify Future Source Modifications

1. **Make your edit** to a file under `src/`
2. **Run the regression suite**: `npm test`
3. **If build verification fails**: read the error, fix the source, rebuild
4. **If you modified a function**: the source-edit test pattern applies — modify, rebuild, verify change in built output, revert, rebuild
5. **Manual browser test**: serve `build/` and verify your change appears in-game

## Adding New Tests

Create a new file in `tests/` (e.g. `tests/verify_new_feature.js`) that:
- Exits with code 0 on success, non-zero on failure
- Uses `console.log` for PASS/FAIL output
- Is added to the `tests` array in `tests/run_regression.js`

## Preserving the Working Build

Before making substantial changes:
1. Run `npm test` to establish a baseline
2. Copy `build/` to a backup location if needed
3. Make changes, rebuild, re-run `npm test`
4. If tests fail, revert and investigate
